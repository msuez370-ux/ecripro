'use strict';

const express = require('express');
const path    = require('path');
const fs      = require('fs');
const nspell  = require('./node_modules/nspell/lib/index.js');

const app  = express();
const PORT = process.env.PORT || 3000;

// ── Fichiers statiques (interface HTML/CSS/JS) ────────────────────────────────
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json({ limit: '2mb' }));

// ── Dossier sauvegardes ───────────────────────────────────────────────────────
const SAVES_DIR = path.join(__dirname, 'saves');
if (!fs.existsSync(SAVES_DIR)) fs.mkdirSync(SAVES_DIR, { recursive: true });

// ── Dictionnaires ─────────────────────────────────────────────────────────────
// Chargés via fs.readFileSync (évite les problèmes ESM des modules dictionary-*)
// Le port est bindé en premier, les dicts se chargent en arrière-plan.
let spellFR = null;
let spellEN = null;

function loadDictionaries() {
  try {
    spellFR = nspell({
      aff: fs.readFileSync(path.join(__dirname, 'node_modules/dictionary-fr/index.aff')),
      dic: fs.readFileSync(path.join(__dirname, 'node_modules/dictionary-fr/index.dic')),
    });
    console.log('  ✓ Dictionnaire Français prêt  (74 000 mots)');
  } catch (e) {
    console.error('  ✗ Dictionnaire FR :', e.message);
  }

  try {
    spellEN = nspell({
      aff: fs.readFileSync(path.join(__dirname, 'node_modules/dictionary-en-us/index.aff')),
      dic: fs.readFileSync(path.join(__dirname, 'node_modules/dictionary-en-us/index.dic')),
    });
    console.log('  ✓ Dictionnaire Anglais prêt   (47 000 mots)');
  } catch (e) {
    console.error('  ✗ Dictionnaire EN :', e.message);
  }

  console.log('');
  console.log('  ÉcriPro est prêt — bonne écriture ! ✍️');
  console.log('');
}

// ════════════════════════════════════════════════════════════
// ROUTES API
// ════════════════════════════════════════════════════════════

// ── POST /api/spellcheck ──────────────────────────────────────────────────────
// Body   : { words: ["mot1", "mot2", ...], lang: "fr" | "en" }
// Retour : { errors: [...], suggestions: { mot: ["sug1", ...] } }
app.post('/api/spellcheck', (req, res) => {
  const { words = [], lang = 'fr' } = req.body;
  const spell = lang === 'en' ? spellEN : spellFR;

  if (!spell) {
    // Dicts pas encore chargés (< 3s après démarrage) — client réessaiera
    return res.json({
      errors:      [],
      suggestions: {},
      warning:     'Dictionnaire en cours de chargement, réessayez dans quelques secondes.',
    });
  }

  const errors      = [];
  const suggestions = {};

  for (const word of words) {
    // Garder uniquement les caractères alphabétiques (FR + EN)
    const clean = word.replace(/[^a-zA-ZÀ-ÿ\u00C0-\u024F'-]/g, '');
    if (clean.length < 2) continue;

    if (!spell.correct(clean)) {
      errors.push(word);
      suggestions[word] = spell.suggest(clean).slice(0, 6);
    }
  }

  res.json({ errors, suggestions });
});

// ── POST /api/save ────────────────────────────────────────────────────────────
// Body   : { filename: "mon-livre.ecripro", content: "..." }
// Retour : { ok: true, filename: "..." }
app.post('/api/save', (req, res) => {
  const { filename, content } = req.body;
  if (!filename || !content) {
    return res.status(400).json({ error: 'Paramètres manquants (filename + content requis)' });
  }

  // Sécuriser : pas de path traversal
  const safe     = path.basename(filename).replace(/[^a-zA-Z0-9\-_.]/g, '');
  const filePath = path.join(SAVES_DIR, safe);

  try {
    fs.writeFileSync(filePath, content, 'utf-8');
    res.json({ ok: true, filename: safe });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ── GET /api/saves ────────────────────────────────────────────────────────────
// Retour : [{ name, size, modified }, ...]  triés par date décroissante
app.get('/api/saves', (req, res) => {
  try {
    const files = fs.readdirSync(SAVES_DIR)
      .filter(f => f.endsWith('.ecripro'))
      .map(f => {
        const stat = fs.statSync(path.join(SAVES_DIR, f));
        return { name: f, size: stat.size, modified: stat.mtime };
      })
      .sort((a, b) => new Date(b.modified) - new Date(a.modified));

    res.json(files);
  } catch {
    res.json([]);
  }
});

// ── GET /api/saves/:filename ──────────────────────────────────────────────────
// Retour : { ok: true, content: "..." }
app.get('/api/saves/:filename', (req, res) => {
  const safe     = path.basename(req.params.filename).replace(/[^a-zA-Z0-9\-_.]/g, '');
  const filePath = path.join(SAVES_DIR, safe);

  if (!fs.existsSync(filePath)) {
    return res.status(404).json({ error: 'Fichier introuvable' });
  }

  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    res.json({ ok: true, content });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ── DELETE /api/saves/:filename ───────────────────────────────────────────────
app.delete('/api/saves/:filename', (req, res) => {
  const safe     = path.basename(req.params.filename).replace(/[^a-zA-Z0-9\-_.]/g, '');
  const filePath = path.join(SAVES_DIR, safe);

  if (!fs.existsSync(filePath)) {
    return res.status(404).json({ error: 'Fichier introuvable' });
  }

  try {
    fs.unlinkSync(filePath);
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ── Page principale (SPA fallback) ────────────────────────────────────────────
app.use((_req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// ════════════════════════════════════════════════════════════
// DÉMARRAGE
// ════════════════════════════════════════════════════════════

app.listen(PORT, '0.0.0.0', () => {
  console.log('');
  console.log('╔═══════════════════════════════════════════════╗');
  console.log('║              ÉcriPro  ✍️                       ║');
  console.log('╠═══════════════════════════════════════════════╣');
  console.log(`║  → http://localhost:${PORT}                      ║`);
  console.log('║  Dans Codespace : cliquez "Open in Browser"   ║');
  console.log('╚═══════════════════════════════════════════════╝');
  console.log('');
  console.log('  Chargement des dictionnaires...');

  // Chargement après binding du port pour ne pas bloquer
  setImmediate(loadDictionaries);
});
