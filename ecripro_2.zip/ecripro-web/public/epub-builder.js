/**
 * ÉcriPro — EPUB 3.0 Builder
 * Génère un fichier EPUB valide Amazon KDP sans dépendances serveur.
 * Utilise JSZip chargé depuis le renderer.
 */

'use strict';

// JSZip is loaded via <script> in index.html — window.JSZip

const EpubBuilder = {

  /**
   * Builds an EPUB 3.0 Blob from book data.
   * @param {Object} book  { title, author, subtitle, description, lang, chapters }
   * @returns {Promise<Blob>}
   */
  async build(book) {
    const JSZip = window.JSZip;
    if (!JSZip) throw new Error('JSZip non chargé');

    const zip = new JSZip();
    const uid = 'ecripro-' + Date.now();
    const lang = book.lang || 'fr';
    const title = book.title || 'Sans titre';
    const author = book.author || 'Auteur inconnu';
    const desc = book.description || '';
    const chapters = book.chapters || [];

    // ── 1. mimetype (must be first, uncompressed) ──────────────────────
    zip.file('mimetype', 'application/epub+zip', { compression: 'STORE' });

    // ── 2. META-INF/container.xml ──────────────────────────────────────
    zip.folder('META-INF').file('container.xml', `<?xml version="1.0" encoding="UTF-8"?>
<container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container">
  <rootfiles>
    <rootfile full-path="EPUB/package.opf" media-type="application/oebps-package+xml"/>
  </rootfiles>
</container>`);

    // ── 3. EPUB folder ─────────────────────────────────────────────────
    const epub = zip.folder('EPUB');

    // ── 4. Stylesheet ──────────────────────────────────────────────────
    epub.file('style.css', this._buildCSS());

    // ── 5. Chapter XHTML files ─────────────────────────────────────────
    const chapterItems = [];
    const spineItems = [];

    // Cover / title page
    epub.file('cover.xhtml', this._buildCoverPage(title, author, subtitle = book.subtitle || ''));
    chapterItems.push({ id: 'cover', href: 'cover.xhtml', mediaType: 'application/xhtml+xml' });
    spineItems.push('cover');

    // TOC page
    epub.file('toc.xhtml', this._buildTOCPage(title, chapters));
    chapterItems.push({ id: 'toc-page', href: 'toc.xhtml', mediaType: 'application/xhtml+xml' });
    spineItems.push('toc-page');

    // Chapters
    chapters.forEach((ch, idx) => {
      const chId = `chapter${idx + 1}`;
      const chFile = `${chId}.xhtml`;
      epub.file(chFile, this._buildChapterXHTML(ch, idx, lang));
      chapterItems.push({ id: chId, href: chFile, mediaType: 'application/xhtml+xml' });
      spineItems.push(chId);
    });

    // ── 6. nav.xhtml (EPUB3 Navigation Document) ──────────────────────
    epub.file('nav.xhtml', this._buildNav(title, chapters));
    chapterItems.push({ id: 'nav', href: 'nav.xhtml', mediaType: 'application/xhtml+xml', properties: 'nav' });

    // ── 7. toc.ncx (EPUB2 compatibility for older Kindles) ────────────
    epub.file('toc.ncx', this._buildNCX(uid, title, author, chapters));
    chapterItems.push({ id: 'ncx', href: 'toc.ncx', mediaType: 'application/x-dtbncx+xml' });

    // ── 8. package.opf ────────────────────────────────────────────────
    epub.file('package.opf', this._buildOPF(uid, title, author, desc, lang, chapterItems, spineItems));

    // ── 9. Generate blob ──────────────────────────────────────────────
    const blob = await zip.generateAsync({
      type: 'blob',
      mimeType: 'application/epub+zip',
      compression: 'DEFLATE',
      compressionOptions: { level: 9 },
    });

    return blob;
  },

  _buildCSS() {
    return `/* ÉcriPro EPUB Stylesheet — Amazon KDP optimized */
@charset "UTF-8";

body {
  font-family: Georgia, "Times New Roman", serif;
  font-size: 1em;
  line-height: 1.7;
  color: #111;
  margin: 0;
  padding: 0;
}

h1, h2, h3 {
  font-family: Georgia, serif;
  margin-top: 1.5em;
  margin-bottom: 0.5em;
  line-height: 1.3;
}

h1 { font-size: 1.6em; text-align: center; page-break-before: always; }
h2 { font-size: 1.3em; }
h3 { font-size: 1.1em; }

p {
  margin: 0;
  text-indent: 1.2em;
}
p.no-indent { text-indent: 0; }
p + p { margin-top: 0; }

blockquote {
  margin: 1em 2em;
  font-style: italic;
  border-left: 3px solid #ccc;
  padding-left: 1em;
}

ul, ol {
  margin: 0.8em 0;
  padding-left: 1.5em;
}

.chapter-title {
  font-size: 1.8em;
  font-weight: bold;
  text-align: center;
  margin-top: 3em;
  margin-bottom: 2em;
  page-break-before: always;
}

.cover-page {
  text-align: center;
  page-break-after: always;
}
.cover-book-title {
  font-size: 2.2em;
  font-weight: bold;
  margin-top: 3em;
  margin-bottom: 0.5em;
}
.cover-subtitle {
  font-size: 1.2em;
  color: #555;
  margin-bottom: 2em;
  font-style: italic;
}
.cover-author {
  font-size: 1.3em;
  margin-top: 3em;
}

.toc-title {
  font-size: 1.6em;
  font-weight: bold;
  margin-bottom: 1em;
  page-break-before: always;
}
.toc-list {
  list-style: none;
  padding: 0;
}
.toc-list li {
  padding: 0.3em 0;
  border-bottom: 1px dotted #ccc;
}
.toc-list a {
  text-decoration: none;
  color: #111;
}

.page-break { page-break-after: always; }
`;
  },

  _buildCoverPage(title, author, subtitle) {
    return `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:epub="http://www.idpf.org/2007/ops" xml:lang="fr">
<head>
  <meta charset="UTF-8"/>
  <title>${this._esc(title)}</title>
  <link rel="stylesheet" type="text/css" href="style.css"/>
</head>
<body>
  <div class="cover-page">
    <div class="cover-book-title">${this._esc(title)}</div>
    ${subtitle ? `<div class="cover-subtitle">${this._esc(subtitle)}</div>` : ''}
    <div class="cover-author">${this._esc(author)}</div>
  </div>
</body>
</html>`;
  },

  _buildTOCPage(title, chapters) {
    const items = chapters.map((ch, i) =>
      `    <li><a href="chapter${i + 1}.xhtml">${this._esc(ch.title || `Chapitre ${i + 1}`)}</a></li>`
    ).join('\n');

    return `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:epub="http://www.idpf.org/2007/ops">
<head>
  <meta charset="UTF-8"/>
  <title>Table des matières</title>
  <link rel="stylesheet" type="text/css" href="style.css"/>
</head>
<body>
  <h1 class="toc-title">Table des matières</h1>
  <ul class="toc-list">
${items}
  </ul>
</body>
</html>`;
  },

  _buildChapterXHTML(chapter, idx, lang) {
    const title = chapter.title || `Chapitre ${idx + 1}`;
    // Convert HTML content to clean XHTML
    const body = this._htmlToXHTML(chapter.content || '');

    return `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:epub="http://www.idpf.org/2007/ops" xml:lang="${lang}">
<head>
  <meta charset="UTF-8"/>
  <title>${this._esc(title)}</title>
  <link rel="stylesheet" type="text/css" href="style.css"/>
</head>
<body>
  <h1 class="chapter-title">${this._esc(title)}</h1>
  ${body}
</body>
</html>`;
  },

  _buildNav(title, chapters) {
    const items = [
      `      <li><a href="cover.xhtml">Couverture</a></li>`,
      `      <li><a href="toc.xhtml">Table des matières</a></li>`,
      ...chapters.map((ch, i) =>
        `      <li><a href="chapter${i + 1}.xhtml">${this._esc(ch.title || `Chapitre ${i + 1}`)}</a></li>`
      )
    ].join('\n');

    return `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:epub="http://www.idpf.org/2007/ops">
<head>
  <meta charset="UTF-8"/>
  <title>Navigation</title>
</head>
<body>
  <nav epub:type="toc" id="toc">
    <h1>Table des matières</h1>
    <ol>
${items}
    </ol>
  </nav>
</body>
</html>`;
  },

  _buildNCX(uid, title, author, chapters) {
    const navPoints = [
      this._ncxNavPoint(1, 'cover', 'Couverture', 'cover.xhtml'),
      this._ncxNavPoint(2, 'toc', 'Table des matières', 'toc.xhtml'),
      ...chapters.map((ch, i) =>
        this._ncxNavPoint(i + 3, `chapter${i + 1}`, ch.title || `Chapitre ${i + 1}`, `chapter${i + 1}.xhtml`)
      )
    ].join('\n');

    return `<?xml version="1.0" encoding="UTF-8"?>
<ncx xmlns="http://www.daisy.org/z3986/2005/ncx/" version="2005-1">
  <head>
    <meta name="dtb:uid" content="${uid}"/>
    <meta name="dtb:depth" content="1"/>
    <meta name="dtb:totalPageCount" content="0"/>
    <meta name="dtb:maxPageNumber" content="0"/>
  </head>
  <docTitle><text>${this._esc(title)}</text></docTitle>
  <docAuthor><text>${this._esc(author)}</text></docAuthor>
  <navMap>
${navPoints}
  </navMap>
</ncx>`;
  },

  _ncxNavPoint(order, id, label, href) {
    return `    <navPoint id="${id}" playOrder="${order}">
      <navLabel><text>${this._esc(label)}</text></navLabel>
      <content src="${href}"/>
    </navPoint>`;
  },

  _buildOPF(uid, title, author, desc, lang, items, spine) {
    const now = new Date().toISOString().split('T')[0];

    const manifestItems = items.map(item => {
      const props = item.properties ? ` properties="${item.properties}"` : '';
      return `    <item id="${item.id}" href="${item.href}" media-type="${item.mediaType}"${props}/>`;
    }).join('\n');

    const spineItems = spine.map(id =>
      `    <itemref idref="${id}"/>`
    ).join('\n');

    const ncxId = items.find(i => i.mediaType === 'application/x-dtbncx+xml')?.id || 'ncx';

    return `<?xml version="1.0" encoding="UTF-8"?>
<package xmlns="http://www.idpf.org/2007/opf" version="3.0" unique-identifier="uid" xml:lang="${lang}">
  <metadata xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:opf="http://www.idpf.org/2007/opf">
    <dc:identifier id="uid">${uid}</dc:identifier>
    <dc:title>${this._esc(title)}</dc:title>
    <dc:creator id="creator">${this._esc(author)}</dc:creator>
    <meta refines="#creator" property="role" scheme="marc:relators">aut</meta>
    <dc:language>${lang}</dc:language>
    <dc:description>${this._esc(desc)}</dc:description>
    <dc:date>${now}</dc:date>
    <dc:publisher>ÉcriPro</dc:publisher>
    <meta property="dcterms:modified">${new Date().toISOString().replace(/\.\d+Z$/, 'Z')}</meta>
  </metadata>
  <manifest>
    <item id="css" href="style.css" media-type="text/css"/>
${manifestItems}
  </manifest>
  <spine toc="${ncxId}">
${spineItems}
  </spine>
</package>`;
  },

  // Convert rich HTML from contenteditable to clean XHTML
  _htmlToXHTML(html) {
    if (!html || !html.trim()) {
      return '<p class="no-indent">&#160;</p>';
    }

    // Handle page breaks
    html = html.replace(/<div[^>]*class="page-break-marker"[^>]*>.*?<\/div>/gi, '<div class="page-break"></div>');

    // Parse with DOM
    const parser = new DOMParser();
    const doc = parser.parseFromString('<div>' + html + '</div>', 'text/html');
    const root = doc.querySelector('div');

    let output = this._nodeToXHTML(root);

    // Wrap bare text in <p> if needed
    if (!output.match(/^<(p|h[1-6]|blockquote|ul|ol|div)/)) {
      output = '<p class="no-indent">' + output + '</p>';
    }

    return output || '<p class="no-indent">&#160;</p>';
  },

  _nodeToXHTML(node) {
    if (!node) return '';
    let out = '';

    for (const child of node.childNodes) {
      if (child.nodeType === 3) { // text
        const t = child.textContent;
        if (t.trim()) out += this._esc(t);
      } else if (child.nodeType === 1) { // element
        const tag = child.tagName.toLowerCase();
        const inner = this._nodeToXHTML(child);

        if (tag === 'b' || tag === 'strong') out += `<strong>${inner}</strong>`;
        else if (tag === 'i' || tag === 'em') out += `<em>${inner}</em>`;
        else if (tag === 'u') out += `<span style="text-decoration:underline;">${inner}</span>`;
        else if (tag === 's' || tag === 'strike') out += `<span style="text-decoration:line-through;">${inner}</span>`;
        else if (['h1','h2','h3'].includes(tag)) out += `<${tag}>${inner}</${tag}>`;
        else if (tag === 'blockquote') out += `<blockquote>${inner}</blockquote>`;
        else if (tag === 'p') out += `<p>${inner || '&#160;'}</p>`;
        else if (tag === 'div') {
          if (child.className.includes('page-break')) out += '<div class="page-break"></div>';
          else out += `<p>${inner}</p>`;
        }
        else if (tag === 'ul') out += `<ul>${inner}</ul>`;
        else if (tag === 'ol') out += `<ol>${inner}</ol>`;
        else if (tag === 'li') out += `<li>${inner}</li>`;
        else if (tag === 'br') out += '<br/>';
        else out += inner;
      }
    }
    return out;
  },

  _esc(str) {
    return String(str || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  },

  // Convert blob to base64
  async blobToBase64(blob) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result.split(',')[1]);
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });
  },
};

window.EpubBuilder = EpubBuilder;
