# ÉcriPro ✍️

Plateforme d'écriture d'ebook dans le navigateur — 100% fonctionnelle sans rien installer sur votre PC.

## Mise en route (5 minutes)

### 1 — Créer le dépôt GitHub

1. Allez sur [github.com](https://github.com) → bouton vert **"New"**
2. Nommez-le `ecripro`, laissez tout par défaut
3. Cliquez **"Create repository"**
4. Sur la page vide qui s'affiche, cliquez **"uploading an existing file"**
5. Décompressez le zip, puis **glissez-déposez tous les fichiers** dans la page
6. Cliquez **"Commit changes"**

### 2 — Ouvrir le Codespace

1. Sur votre dépôt → bouton vert **"Code"** → onglet **"Codespaces"**
2. Cliquez **"Create codespace on main"**
3. Attendez ~1 minute (Node.js + `npm install` s'exécutent automatiquement)

### 3 — Lancer l'application

Dans le terminal en bas de VS Code (Codespace) :

```bash
npm start
```

Un popup apparaît en bas à droite → cliquez **"Open in Browser"**.

**ÉcriPro s'ouvre. C'est tout. ✓**

---

## Utilisation quotidienne

La prochaine fois :
1. [github.com](https://github.com) → votre dépôt `ecripro`
2. Bouton **"Code"** → **"Codespaces"** → cliquer sur votre Codespace existant
3. Terminal → `npm start` → **"Open in Browser"**

---

## Fonctionnalités

| Fonctionnalité | Détail |
|---|---|
| ✍️ Éditeur riche | Gras, italique, titres H1/H2/H3, citations, listes, sauts de page |
| 👁️ Aperçu temps réel | Kindle, A5 impression, Web |
| 📖 Correcteur offline FR | 74 000 mots — fonctionne sans internet |
| 📖 Correcteur offline EN | 47 000 mots — fonctionne sans internet |
| 💾 Bibliothèque | Sauvegarde de vos livres sur le serveur (bouton 📂) |
| 📤 Export EPUB 3.0 | Prêt pour Amazon KDP, téléchargement direct |
| ✦ Assistant IA | Correction, style, idées, définitions, description KDP |
| 🔍 Rechercher/Remplacer | Ctrl+F dans l'éditeur |
| 🎯 Mode focus | F11 — écriture sans distraction |

---

## Architecture

```
ecripro/
├── server.js                   ← Serveur Express (correcteur + sauvegarde)
├── package.json                ← Dépendances npm
├── .gitignore
├── .devcontainer/
│   └── devcontainer.json       ← Config Codespace (Node 20, port 3000 auto-ouvert)
└── public/                     ← Interface web (servi par Express)
    ├── index.html              ← Page principale
    ├── style.css               ← Styles
    ├── app.js                  ← Logique de l'application
    └── epub-builder.js         ← Générateur EPUB 3.0 (JSZip, côté navigateur)
```

Les livres sont sauvegardés dans `saves/` (créé automatiquement, ignoré par git).

---

## Raccourcis clavier

| Action | Raccourci |
|---|---|
| Sauvegarder | `Ctrl+S` |
| Rechercher / Remplacer | `Ctrl+F` |
| Saut de page | `Ctrl+Entrée` |
| Mode focus | `F11` |

---

## Publier sur Amazon KDP

1. Bouton **📤 EPUB / KDP** → remplissez titre, auteur, description
2. Cliquez **"Télécharger EPUB"** → fichier `.epub` téléchargé
3. Sur [kdp.amazon.com](https://kdp.amazon.com) → Nouveau titre Kindle → uploadez le `.epub`
4. KDP valide automatiquement le format EPUB 3.0

> 💡 Utilisez l'assistant IA (bouton **✦**) → **"📚 KDP"** pour générer une description optimisée Amazon.
